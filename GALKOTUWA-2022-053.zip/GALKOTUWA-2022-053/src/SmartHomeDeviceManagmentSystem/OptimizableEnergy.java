package SmartHomeDeviceManagmentSystem;

public interface OptimizableEnergy {
    void optimizeEnergyUsage();
}
