package SmartHomeDeviceManagmentSystem;

public interface SmartDevice {
    void calculateEnergyConsumption();
}
